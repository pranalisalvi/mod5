package com.capgemini.appl.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityService {

	List<Application> showApplications() throws UniversityAdmissionException;

	boolean addProgram(ProgramsOffered p) throws UniversityAdmissionException;
	
	List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException;

	boolean acceptOrRejectApplication(Application application) throws UniversityAdmissionException;
	boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException;

	boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException;
	
	Users getUserDetail(String userName)throws UniversityAdmissionException;
	String isUserAuthanticate(String userName,String password)throws UniversityAdmissionException;
	List<ProgramsScheduled> getAllProgramSheduled()throws UniversityAdmissionException;
	List<Application> getApplicationOnSheduledId(String ScheduleId)throws UniversityAdmissionException;
	boolean updateApplicationDB(int id,String status)throws UniversityAdmissionException;
	//////////////////////////////////////////////////////////
	List<ProgramsOffered> getAllProgramDetails()throws UniversityAdmissionException;
	String insertLocationDetails(Location loc)throws UniversityAdmissionException;
	boolean insertScheduledDetails(ProgramsScheduled schedule)throws UniversityAdmissionException;
	boolean deleteSchedule(String id)throws UniversityAdmissionException;
	
	public List<Application> showApplicantInfo(int id) throws UniversityAdmissionException;
	
	//////////////////////////////////////////////////
	public int getApplicationId()throws UniversityAdmissionException;
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException;
	public int addApplicant(Application appl) throws UniversityAdmissionException;
	public Application showStatus(int application_id) throws UniversityAdmissionException;
	
	public List<ProgramsScheduled> showProgramInfo(Date startdate,Date enddate) throws UniversityAdmissionException;
	public int getProgramId(String programName)throws UniversityAdmissionException ;
	
	//////////////////////////////////////////////////////////Modified///////////////////////
	public List<ProgramsScheduled> getAllProgramSheduled(String programName)throws UniversityAdmissionException;


}
